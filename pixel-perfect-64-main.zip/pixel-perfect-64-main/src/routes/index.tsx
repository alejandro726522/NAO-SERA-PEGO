import { createFileRoute } from "@tanstack/react-router";
import { sendLeadCapi } from "@/lib/meta-capi.functions";
import duduMascot from "@/assets/dudu-mascot.png";
import lpCover from "@/assets/lp-cover-v2.webp";

// ===== Configurações fáceis de trocar =====
const TELEGRAM_LINK = "https://t.me/dudufaisca";
const GROUP_NAME = "Dudu Faísca";
// Domínio publicado (troque ao conectar um domínio próprio) — usado no preview do link (og:image).
const SITE_URL = "https://pixel-perfect-64.lovable.app";
const OG_IMAGE = `${SITE_URL}/poster.jpg`;
// Responsável e contato exibidos no rodapé (transparência / LGPD).
const RESPONSIBLE = "Dudu Faísca";
const CONTACT_EMAIL = "contato@exemplo.com"; // TROQUE pelo seu e-mail real antes de rodar tráfego.
const HERO_BG = lpCover;

const TITLE = "Dudu Faísca · Grupo VIP";
const DESC = "Entre no grupo VIP Dudu Faísca e acompanhe os conteúdos em primeira mão.";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: TITLE },
      { name: "description", content: DESC },
      { property: "og:title", content: TITLE },
      { property: "og:description", content: DESC },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: OG_IMAGE },
      { property: "og:url", content: SITE_URL },
      { name: "twitter:image", content: OG_IMAGE },
    ],
  }),
  component: Index,
});

// Dispara o evento "Lead" no clique do CTA: via Meta Pixel (navegador)
// e via API de Conversões (servidor), com o mesmo eventId para deduplicar.
function trackLead() {
  const w = window as unknown as { fbq?: (...a: unknown[]) => void };
  const eventId =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : `${Date.now()}-${Math.random().toString(36).slice(2, 12)}`;
  if (typeof w.fbq === "function")
    w.fbq("track", "Lead", {}, { eventID: eventId });
  const fbp = document.cookie.match(/_fbp=([^;]+)/)?.[1];
  sendLeadCapi({
    data: { eventId, fbp, sourceUrl: window.location.href },
  }).catch(() => {});
}

const COINS = [
  { left: "4%", delay: 0, dur: 2.2 }, { left: "14%", delay: 0.5, dur: 2.6 },
  { left: "24%", delay: 1.1, dur: 2.3 }, { left: "33%", delay: 0.2, dur: 2.8 },
  { left: "42%", delay: 0.8, dur: 2.1 }, { left: "50%", delay: 1.4, dur: 2.7 },
  { left: "58%", delay: 0.4, dur: 2.4 }, { left: "67%", delay: 1.0, dur: 2.9 },
  { left: "76%", delay: 0.1, dur: 2.2 }, { left: "85%", delay: 0.7, dur: 2.5 },
  { left: "94%", delay: 1.3, dur: 2.3 }, { left: "9%", delay: 1.7, dur: 2.6 },
  { left: "47%", delay: 1.9, dur: 2.4 }, { left: "72%", delay: 1.6, dur: 2.8 },
];

type Sym = "seven" | "cherry" | "lemon" | "bell" | "diamond" | "star";
// Posições 0 e 19 precisam ser "seven" para o giro em loop parar sempre no jackpot.
const STRIP: Sym[] = ["seven", "cherry", "lemon", "bell", "diamond", "star", "cherry", "seven", "lemon", "diamond", "star", "bell", "cherry", "diamond", "seven", "star", "bell", "cherry", "diamond", "seven"];

const Sym = ({ kind }: { kind: Sym }) => {
  switch (kind) {
    case "seven":
      return (
        <svg viewBox="0 0 40 40">
          <text x="20" y="32" textAnchor="middle" fontSize="32" fontWeight="900" fontFamily="Anton, sans-serif" fill="#f2d98d" stroke="#8a6a25" strokeWidth="1.2">7</text>
        </svg>
      );
    case "cherry":
      return (
        <svg viewBox="0 0 40 40">
          <path d="M20 5 C16 11 13 16 13 22" stroke="#2f9e63" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          <path d="M20 5 C24 11 28 15 28 20" stroke="#2f9e63" strokeWidth="2.5" fill="none" strokeLinecap="round" />
          <circle cx="13" cy="28" r="7" fill="#e0313c" />
          <circle cx="28" cy="26" r="6.5" fill="#c8242f" />
          <circle cx="10.5" cy="25.5" r="2" fill="#ff9aa0" opacity=".85" />
        </svg>
      );
    case "lemon":
      return (
        <svg viewBox="0 0 40 40">
          <ellipse cx="20" cy="23" rx="12" ry="8.5" fill="#f7d537" transform="rotate(-18 20 23)" />
          <ellipse cx="20" cy="23" rx="12" ry="8.5" fill="none" stroke="#d9b41f" strokeWidth="1.5" transform="rotate(-18 20 23)" />
          <circle cx="14" cy="20" r="2" fill="#fce990" opacity=".9" />
        </svg>
      );
    case "bell":
      return (
        <svg viewBox="0 0 40 40">
          <path d="M20 8c-6 0-9 5-9 10 0 6-2 8-4 10h26c-2-2-4-4-4-10 0-5-3-10-9-10z" fill="#f0c548" stroke="#c9992b" strokeWidth="1.2" />
          <circle cx="20" cy="31.5" r="3" fill="#c9992b" />
          <circle cx="20" cy="6.5" r="2.5" fill="#c9992b" />
        </svg>
      );
    case "diamond":
      return (
        <svg viewBox="0 0 40 40">
          <polygon points="20,5 33,15 20,35 7,15" fill="#4fd8ab" />
          <polygon points="20,5 27,15 20,35 13,15" fill="#8ff0d1" />
          <polygon points="7,15 33,15" fill="none" stroke="#2ea881" strokeWidth="1.2" />
        </svg>
      );
    case "star":
      return (
        <svg viewBox="0 0 40 40">
          <polygon points="20,4 24.7,14.6 36,15.8 27.6,23.5 30,35 20,29 10,35 12.4,23.5 4,15.8 15.3,14.6" fill="#f2c94c" stroke="#c9992b" strokeWidth="1.2" />
        </svg>
      );
  }
};

const SlotMachine = () => (
  <div className="lp-slots" aria-hidden="true">
    <div className="lp-slots__machine">
      <div className="lp-slots__reel"><div className="lp-slots__strip lp-slots__strip--a">{STRIP.map((s, i) => <span key={i}><Sym kind={s} /></span>)}</div></div>
      <div className="lp-slots__reel"><div className="lp-slots__strip lp-slots__strip--b">{STRIP.map((s, i) => <span key={i}><Sym kind={s} /></span>)}</div></div>
      <div className="lp-slots__reel"><div className="lp-slots__strip lp-slots__strip--c">{STRIP.map((s, i) => <span key={i}><Sym kind={s} /></span>)}</div></div>
    </div>
    <div className="lp-slots__coins">
      {COINS.map((c, i) => (
        <span key={i} className="lp-coin" style={{ left: c.left, animationDelay: `${c.delay}s`, animationDuration: `${c.dur}s` }} />
      ))}
    </div>
  </div>
);

// Símbolos de slots flutuando ao fundo do hero (decorativo)
const BG_SYMBOLS: { kind: Sym; left: string; top: string; size: number; dur: number; delay: number; peak: number }[] = [
  { kind: "seven",   left: "6%",  top: "16%", size: 46, dur: 10,   delay: 0,   peak: 0.42 },
  { kind: "cherry",  left: "88%", top: "12%", size: 38, dur: 11.5, delay: 1.2, peak: 0.38 },
  { kind: "diamond", left: "10%", top: "44%", size: 34, dur: 9,    delay: 2.4, peak: 0.34 },
  { kind: "bell",    left: "90%", top: "40%", size: 40, dur: 12,   delay: 0.8, peak: 0.36 },
  { kind: "star",    left: "4%",  top: "68%", size: 30, dur: 10.5, delay: 3.1, peak: 0.3 },
  { kind: "seven",   left: "92%", top: "66%", size: 32, dur: 9.5,  delay: 1.9, peak: 0.32 },
  { kind: "lemon",   left: "16%", top: "6%",  size: 28, dur: 13,   delay: 4.2, peak: 0.28 },
  { kind: "diamond", left: "80%", top: "84%", size: 30, dur: 11,   delay: 2.8, peak: 0.3 },
];

const BgSymbols = () => (
  <div className="lp-bg-symbols" aria-hidden="true">
    {BG_SYMBOLS.map((s, i) => (
      <span
        key={i}
        style={{
          left: s.left,
          top: s.top,
          "--size": `${s.size}px`,
          "--dur": `${s.dur}s`,
          "--delay": `${s.delay}s`,
          "--peak": s.peak,
        } as React.CSSProperties}
      >
        <Sym kind={s.kind} />
      </span>
    ))}
  </div>
);

const Chevron = () => (
  <svg viewBox="0 0 28 16" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
    <path d="M3 3l11 10L25 3" />
  </svg>
);

function Index() {
  return (
    <main>
      <section className="lp-hero" aria-label="Dudu Faísca Grupo VIP — participe agora do grupo no Telegram">
        <div className="lp-hero__art" style={{ backgroundImage: `url(${HERO_BG})` }} aria-hidden="true" />
        <div className="lp-hero__overlay" aria-hidden="true" />
        <BgSymbols />
        <div className="lp-hero__content">
          <div className="lp-dudu" aria-hidden="true">
            <span className="lp-dudu__rays" />
            <span className="lp-dudu__glow" />
            <img src={duduMascot} alt="" className="lp-dudu__img" />
          </div>
          <SlotMachine />
          <p className="lp-eyebrow">Grupo VIP</p>
          <h1 className="lp-title">Dudu Faísca</h1>
          <p className="lp-sub">Participe agora</p>
          <div className="lp-arrows" aria-hidden="true">
            <Chevron />
            <Chevron />
            <Chevron />
          </div>
        </div>
      </section>

      <footer className="lp-footer">
        <div className="lp-footer__inner">
          <p className="lp-tag">Informações da comunidade</p>
          <h2>{GROUP_NAME}</h2>
          <p>O grupo {GROUP_NAME} no Telegram é um grupo VIP de conteúdos. Esta página apresenta o acesso ao convite desse grupo.</p>
          <p>Ao tocar em "Acessar grupo VIP", você abre o convite no Telegram. Confira o nome do grupo antes de decidir participar. Abrir o convite não confirma sua entrada.</p>

          <p className="lp-label">Responsável por esta página</p>
          <p className="lp-value">{RESPONSIBLE}</p>
          <p className="lp-label">Contato e privacidade</p>
          <p className="lp-value">
            <a href={`mailto:${CONTACT_EMAIL}`}>{CONTACT_EMAIL}</a>
          </p>

          <details className="lp-policy">
            <summary>Política de Privacidade</summary>
            <div className="lp-policy__body">
              <h3>Como esta página usa dados</h3>
              <p>{RESPONSIBLE} é responsável pelo tratamento dos dados desta página. Para dúvidas ou solicitações de acesso, correção ou exclusão de dados, escreva para {CONTACT_EMAIL}.</p>
              <p>Em visitas vindas de anúncios, o Meta Pixel e a API de Conversões da Meta podem registrar a visualização da página e o clique no botão para entrar no grupo.</p>
              <p>Esses dados podem incluir a URL e seus parâmetros, data e horário, endereço IP, informações do navegador e identificadores de visitante ou de clique.</p>
              <p>Esta página não pede seu telefone nem seu e-mail e não lê mensagens do Telegram.</p>
              <p>Cookies podem guardar esses identificadores por até 90 dias. Saiba mais na <a href="https://www.facebook.com/privacy/policy/" target="_blank" rel="noopener noreferrer">Política de Privacidade da Meta</a>.</p>
            </div>
          </details>
        </div>
      </footer>

      <div className="lp-cta-bar">
        <a className="lp-btn" href={TELEGRAM_LINK} target="_blank" rel="noopener noreferrer" onClick={trackLead}>
          <span className="lp-btn__chip" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="#fff">
              <path d="M9.78 18.65l.28-4.23 7.68-6.92c.34-.31-.07-.46-.52-.19L7.74 13.3 3.64 12c-.88-.25-.89-.86.2-1.3l15.97-6.16c.73-.33 1.43.18 1.15 1.3l-2.72 12.81c-.19.91-.74 1.13-1.5.71L12.6 16.3l-1.99 1.93c-.23.23-.42.42-.83.42z" />
            </svg>
          </span>
          <span className="lp-btn__text">
            <strong>Acessar grupo VIP</strong>
            <small>Entrada gratuita no Telegram</small>
          </span>
          <svg className="lp-btn__arrow" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <path d="M5 12h14M13 6l6 6-6 6" />
          </svg>
        </a>
      </div>
    </main>
  );
}
